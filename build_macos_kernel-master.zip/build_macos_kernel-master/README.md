## build macOS kernel

- [x] XNU version 6153.11.26 on macOS Catalina 10.15 with Xcode 11.13.1.

## ref url

[https://github.com/actions/virtual-environments/blob/main/images/macos/macos-10.15-Readme.md](https://github.com/actions/virtual-environments/blob/main/images/macos/macos-10.15-Readme.md)

[afrighetto/build-xnu.sh](https://gist.github.com/afrighetto/e47b990f52586b4797297e7548e6352c)
